#ifndef Root_estimation_H
#define Root_estimation_H

double func(double x);
double func_root();
int max_iter = 10;
double accuracy = 0.0001;

#endif
